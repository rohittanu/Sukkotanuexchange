import { and, asc, count, desc, eq, gte, ilike, lte, or, sql } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CreatePropertyBody,
  CreatePropertyResponse,
  GetPropertyParams,
  GetPropertyResponse,
  GetPropertySummaryResponse,
  ListPropertiesQueryParams,
  ListPropertiesResponse,
} from "@workspace/api-zod";
import { db, propertiesTable } from "@workspace/db";

const router: IRouter = Router();

function toPropertyResponse(
  property: typeof propertiesTable.$inferSelect,
): Omit<typeof propertiesTable.$inferSelect, "createdAt"> & { createdAt: string } {
  return { ...property, createdAt: property.createdAt.toISOString() };
}

router.get("/properties", async (req, res): Promise<void> => {
  const parsed = ListPropertiesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { q, transactionType, propertyType, city, minPrice, maxPrice, minBedrooms, featured, sort } = parsed.data;
  const filters = [];

  if (q) {
    const pattern = `%${q}%`;
    filters.push(
      or(
        ilike(propertiesTable.title, pattern),
        ilike(propertiesTable.description, pattern),
        ilike(propertiesTable.locality, pattern),
        ilike(propertiesTable.city, pattern),
        ilike(propertiesTable.state, pattern),
      ),
    );
  }
  if (transactionType) filters.push(eq(propertiesTable.transactionType, transactionType));
  if (propertyType) filters.push(eq(propertiesTable.propertyType, propertyType));
  if (city) filters.push(ilike(propertiesTable.city, city));
  if (minPrice !== undefined) filters.push(gte(propertiesTable.price, minPrice));
  if (maxPrice !== undefined) filters.push(lte(propertiesTable.price, maxPrice));
  if (minBedrooms !== undefined) filters.push(gte(propertiesTable.bedrooms, minBedrooms));
  if (featured !== undefined) filters.push(eq(propertiesTable.featured, featured));

  const orderBy =
    sort === "price_asc"
      ? asc(propertiesTable.price)
      : sort === "price_desc"
        ? desc(propertiesTable.price)
        : desc(propertiesTable.createdAt);
  const rows = await db
    .select()
    .from(propertiesTable)
    .where(filters.length ? and(...filters) : undefined)
    .orderBy(orderBy);

  res.json(ListPropertiesResponse.parse(rows.map(toPropertyResponse)));
});

router.get("/properties/summary", async (_req, res): Promise<void> => {
  const [summary] = await db
    .select({
      totalListings: count(),
      forSaleCount: sql<number>`count(*) filter (where ${propertiesTable.transactionType} = 'buy')`,
      forRentCount: sql<number>`count(*) filter (where ${propertiesTable.transactionType} = 'rent')`,
      cityCount: sql<number>`count(distinct ${propertiesTable.city})`,
    })
    .from(propertiesTable);

  res.json(
    GetPropertySummaryResponse.parse({
      totalListings: Number(summary.totalListings),
      forSaleCount: Number(summary.forSaleCount),
      forRentCount: Number(summary.forRentCount),
      cityCount: Number(summary.cityCount),
    }),
  );
});

router.get("/properties/:id", async (req, res): Promise<void> => {
  const params = GetPropertyParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [property] = await db
    .select()
    .from(propertiesTable)
    .where(eq(propertiesTable.id, params.data.id));

  if (!property) {
    res.status(404).json({ error: "Property not found" });
    return;
  }

  res.json(GetPropertyResponse.parse(toPropertyResponse(property)));
});

router.post("/properties", async (req, res): Promise<void> => {
  const parsed = CreatePropertyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [property] = await db
    .insert(propertiesTable)
    .values(parsed.data)
    .returning();

  req.log.info({ propertyId: property.id }, "Property listing created");
  res.status(201).json(CreatePropertyResponse.parse(toPropertyResponse(property)));
});

export default router;