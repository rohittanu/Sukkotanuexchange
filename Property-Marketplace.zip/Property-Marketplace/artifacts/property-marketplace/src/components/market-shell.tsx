import type { ReactNode } from 'react';
import { Link } from 'wouter';
import { ArrowUpRight, MapPin } from 'lucide-react';

export function MarketShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-[100dvh] bg-background text-foreground">
      <header className="border-b border-border/80 bg-background/90">
        <div className="site-shell flex h-[76px] items-center justify-between">
          <Link href="/" className="group flex flex-col leading-none" data-testid="link-home">
            <span className="font-sans text-[16px] font-bold tracking-[.04em] sm:text-[18px]">SUKKO EXCHANGE</span>
            <span className="mt-1 text-[9px] font-bold uppercase tracking-[.19em] text-muted-foreground">TANU PROPERTIES</span>
          </Link>
          <nav className="flex items-center gap-5 sm:gap-8">
            <Link href="/" className="nav-link hidden text-sm font-medium sm:inline" data-testid="link-browse">Find a home</Link>
            <Link href="/list-property" className="flex items-center gap-2 rounded-full bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition hover:bg-primary/90" data-testid="link-list-property">
              List your property <ArrowUpRight size={15} />
            </Link>
          </nav>
        </div>
      </header>
      <main>{children}</main>
      <footer className="mt-20 border-t border-border bg-secondary/40">
        <div className="site-shell flex flex-col gap-5 py-8 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2 text-sm font-medium"><MapPin size={15} className="text-accent" /> Homes, found with care.</div>
          <p className="text-xs text-muted-foreground">Made for the moments that make a place yours.</p>
          <Link href="/list-property" className="text-xs font-semibold text-primary hover:underline" data-testid="link-footer-list">Have a home to share? List it</Link>
        </div>
      </footer>
    </div>
  );
}

export function formatINR(value: number, compact = false) {
  if (compact && value >= 10000000) return `₹${(value / 10000000).toFixed(value % 10000000 === 0 ? 0 : 1)} Cr`;
  if (compact && value >= 100000) return `₹${(value / 100000).toFixed(value % 100000 === 0 ? 0 : 1)} L`;
  return `₹${new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 }).format(value)}`;
}

export function PropertyPhoto({ src, title, className = '' }: { src: string; title: string; className?: string }) {
  return (
    <div className={`relative overflow-hidden bg-[linear-gradient(135deg,#d9e2d8,#f0dfc7_55%,#b8c9be)] ${className}`}>
      {src ? <img src={src} alt={title} className="h-full w-full object-cover" loading="lazy" onError={(event) => { event.currentTarget.style.display = 'none'; }} /> : null}
      <div aria-hidden="true" className="absolute inset-0 -z-0 opacity-25" style={{ backgroundImage: 'radial-gradient(circle at 20% 20%, #fff 0 1px, transparent 1.5px)', backgroundSize: '16px 16px' }} />
    </div>
  );
}