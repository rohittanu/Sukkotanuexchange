import { Link } from 'wouter';
import { BedDouble, MapPin, MoveUpRight, Ruler } from 'lucide-react';
import type { Property } from '@workspace/api-client-react';
import { formatINR, PropertyPhoto } from './market-shell';

export function PropertyCard({ property }: { property: Property }) {
  return (
    <article className="property-card overflow-hidden rounded-[20px] border border-border bg-card" data-testid={`card-property-${property.id}`}>
      <Link href={`/property/${property.id}`} className="block" data-testid={`link-property-${property.id}`}>
        <div className="relative h-[218px]">
          <PropertyPhoto src={property.imageUrl} title={property.title} className="h-full w-full" />
          <div className="image-wash absolute inset-0" />
          <div className="absolute left-4 top-4 flex gap-2">
            <span className="rounded-full bg-card/95 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[.1em] text-primary">{property.transactionType === 'buy' ? 'For sale' : 'For rent'}</span>
            {property.featured && <span className="rounded-full bg-accent px-3 py-1.5 text-[10px] font-bold uppercase tracking-[.1em] text-accent-foreground">Featured</span>}
          </div>
          <p className="absolute bottom-4 left-4 font-serif text-[27px] font-semibold leading-none text-white" data-testid={`text-price-${property.id}`}>{formatINR(property.price, true)}{property.transactionType === 'rent' ? <span className="font-sans text-xs font-medium"> / month</span> : null}</p>
        </div>
        <div className="p-5">
          <div className="mb-2 flex items-start justify-between gap-3">
            <h2 className="font-serif text-[20px] font-semibold leading-tight tracking-[-.025em]">{property.title}</h2>
            <MoveUpRight size={17} className="mt-1 shrink-0 text-muted-foreground transition group-hover:text-accent" />
          </div>
          <p className="mb-4 flex items-center gap-1.5 text-sm text-muted-foreground"><MapPin size={14} />{property.locality}, {property.city}</p>
          <div className="flex items-center gap-4 border-t border-border pt-4 text-xs font-medium text-muted-foreground">
            {property.bedrooms > 0 && <span className="flex items-center gap-1.5"><BedDouble size={15} />{property.bedrooms} bed</span>}
            <span className="flex items-center gap-1.5"><Ruler size={14} />{new Intl.NumberFormat('en-IN').format(property.areaSqft)} sq ft</span>
            <span className="ml-auto capitalize">{property.propertyType}</span>
          </div>
        </div>
      </Link>
    </article>
  );
}