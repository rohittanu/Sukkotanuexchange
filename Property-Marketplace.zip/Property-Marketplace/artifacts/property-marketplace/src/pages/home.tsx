import { type FormEvent, useMemo, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useGetPropertySummary, useListProperties } from '@workspace/api-client-react';
import type { ListPropertiesParams, PropertyType } from '@workspace/api-client-react';
import { ArrowDownUp, ArrowRight, BedDouble, ChevronDown, MapPin, Search, SlidersHorizontal } from 'lucide-react';
import { MarketShell } from '@/components/market-shell';
import { PropertyCard } from '@/components/property-card';

const propertyTypes: { value: PropertyType | ''; label: string }[] = [
  { value: '', label: 'Any home type' }, { value: 'apartment', label: 'Apartment' }, { value: 'house', label: 'House' },
  { value: 'villa', label: 'Villa' }, { value: 'townhouse', label: 'Townhouse' }, { value: 'land', label: 'Land' },
];
const initialFilters = () => {
  const search = new URLSearchParams(window.location.search);
  return {
    q: search.get('q') ?? '', transactionType: search.get('transactionType') ?? '',
    propertyType: search.get('propertyType') ?? '', city: search.get('city') ?? '',
    minPrice: search.get('minPrice') ?? '', maxPrice: search.get('maxPrice') ?? '',
    minBedrooms: search.get('minBedrooms') ?? '', sort: search.get('sort') ?? 'recent',
  };
};

export default function HomePage() {
  const [, setLocation] = useLocation();
  const [filters, setFilters] = useState(initialFilters);
  const [active, setActive] = useState(initialFilters);
  const params = useMemo<ListPropertiesParams>(() => ({
    q: active.q || undefined, transactionType: (active.transactionType || undefined) as ListPropertiesParams['transactionType'],
    propertyType: (active.propertyType || undefined) as PropertyType | undefined,
    city: active.city || undefined, minPrice: active.minPrice ? Number(active.minPrice) : undefined,
    maxPrice: active.maxPrice ? Number(active.maxPrice) : undefined,
    minBedrooms: active.minBedrooms ? Number(active.minBedrooms) : undefined,
    sort: active.sort as ListPropertiesParams['sort'],
  }), [active]);
  const listings = useListProperties(params);
  const summary = useGetPropertySummary();
  const update = (key: keyof typeof filters, value: string) => setFilters((current) => ({ ...current, [key]: value }));
  const applyFilters = (event: FormEvent) => {
    event.preventDefault();
    setActive({ ...filters });
    const query = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => { if (value && !(key === 'sort' && value === 'recent')) query.set(key, value); });
    setLocation(query.toString() ? `/?${query.toString()}` : '/');
  };
  const clearFilters = () => {
    const cleared = { ...initialFilters(), q: '', city: '', transactionType: '', propertyType: '', minPrice: '', maxPrice: '', minBedrooms: '', sort: 'recent' };
    setFilters(cleared); setActive(cleared); setLocation('/');
  };

  return (
    <MarketShell>
      <section className="relative overflow-hidden bg-primary text-primary-foreground">
        <div className="absolute -right-16 top-[-90px] h-[390px] w-[390px] rounded-full border border-white/10" />
        <div className="absolute right-[9%] top-8 h-[310px] w-[310px] rounded-full border border-white/10" />
        <div className="site-shell relative grid min-h-[420px] items-center gap-8 py-14 md:grid-cols-[1fr_320px] md:py-16">
          <div className="reveal">
            <p className="eyebrow mb-5 text-[#d7b99b]">A home is more than an address</p>
            <h1 className="serif max-w-[740px] text-[clamp(42px,6.5vw,76px)] font-medium leading-[1.02] tracking-[-.055em]">Find a place that<br className="hidden sm:block" /> feels like <em className="font-medium text-[#edb18e]">your own.</em></h1>
            <p className="mt-6 max-w-[480px] text-[15px] leading-7 text-primary-foreground/75">Thoughtful homes, honest details, and a better way to make your next move across India.</p>
            <div className="mt-7 flex items-center gap-2 text-xs text-primary-foreground/65"><span className="h-1.5 w-1.5 rounded-full bg-[#e3aa83]" /> Clear listings from real owners and local sellers</div>
          </div>
          <aside className="relative hidden rounded-[26px] border border-white/15 bg-white/[.07] p-6 backdrop-blur-sm md:block">
            <div className="eyebrow text-[#d7b99b]">The market, today</div>
            {summary.isLoading ? <div className="mt-5 space-y-4"><div className="h-8 w-28 animate-pulse rounded bg-white/10" /><div className="h-8 w-36 animate-pulse rounded bg-white/10" /></div> :
              summary.data ? <div className="mt-5 space-y-5">
                <div><p className="serif text-4xl">{new Intl.NumberFormat('en-IN').format(summary.data.totalListings)}</p><p className="mt-1 text-xs text-primary-foreground/65">homes to make your own</p></div>
                <div className="grid grid-cols-2 gap-3 border-t border-white/15 pt-4">
                  <div><p className="text-lg font-semibold">{new Intl.NumberFormat('en-IN').format(summary.data.forSaleCount)}</p><p className="text-[11px] text-primary-foreground/60">for sale</p></div>
                  <div><p className="text-lg font-semibold">{new Intl.NumberFormat('en-IN').format(summary.data.forRentCount)}</p><p className="text-[11px] text-primary-foreground/60">for rent</p></div>
                </div>
                <p className="flex items-center gap-2 text-xs text-primary-foreground/65"><MapPin size={13} />Across {summary.data.cityCount} cities</p>
              </div> : <p className="mt-5 text-xs text-primary-foreground/70">Market totals are temporarily unavailable.</p>}
          </aside>
        </div>
      </section>

      <section className="site-shell relative -mt-8">
        <form onSubmit={applyFilters} className="rounded-[20px] border border-border bg-card p-4 shadow-[0_14px_40px_rgba(25,55,47,.09)] sm:p-5" data-testid="form-search">
          <div className="mb-4 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[.13em] text-muted-foreground"><SlidersHorizontal size={14} className="text-accent" /> Find your kind of place</div>
          <div className="grid gap-3 md:grid-cols-[1.4fr_1fr_1fr_auto]">
            <label className="relative block">
              <span className="sr-only">Search by locality or keyword</span>
              <Search size={17} className="absolute left-4 top-[15px] text-muted-foreground" />
              <input value={filters.q} onChange={(e) => update('q', e.target.value)} placeholder="Locality, landmark or keyword" className="field field-with-icon" data-testid="input-search" />
            </label>
            <label className="relative block">
              <span className="sr-only">City</span><MapPin size={16} className="absolute left-4 top-[15px] text-muted-foreground" />
              <input value={filters.city} onChange={(e) => update('city', e.target.value)} placeholder="City" className="field field-with-icon" data-testid="input-city" />
            </label>
            <label className="relative block">
              <span className="sr-only">Property type</span>
              <select value={filters.propertyType} onChange={(e) => update('propertyType', e.target.value)} className="field appearance-none pr-9" data-testid="select-property-type">
                {propertyTypes.map((type) => <option key={type.label} value={type.value}>{type.label}</option>)}
              </select><ChevronDown size={15} className="pointer-events-none absolute right-4 top-4 text-muted-foreground" />
            </label>
            <button className="flex items-center justify-center gap-2 rounded-xl bg-accent px-7 py-3 text-sm font-bold text-accent-foreground transition hover:brightness-95" type="submit" data-testid="button-search"><Search size={16} /> Search homes</button>
          </div>
          <div className="mt-3 grid gap-3 sm:grid-cols-2 md:grid-cols-[1fr_1fr_1fr_auto]">
            <div className="flex rounded-xl bg-secondary/60 p-1">
              {[['', 'Buy or rent'], ['buy', 'Buy'], ['rent', 'Rent']].map(([value, label]) => (
                <button key={label} type="button" onClick={() => update('transactionType', value)} className={`flex-1 rounded-lg px-3 py-2 text-xs font-semibold transition ${filters.transactionType === value ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground hover:text-foreground'}`} data-testid={`filter-${label.toLowerCase().replaceAll(' ', '-')}`}>{label}</button>
              ))}
            </div>
            <input type="number" min="0" value={filters.minPrice} onChange={(e) => update('minPrice', e.target.value)} placeholder="Min budget (₹)" className="field py-2.5 text-sm" data-testid="input-min-price" />
            <input type="number" min="0" value={filters.maxPrice} onChange={(e) => update('maxPrice', e.target.value)} placeholder="Max budget (₹)" className="field py-2.5 text-sm" data-testid="input-max-price" />
            <div className="flex items-center justify-between gap-3">
              <label className="flex items-center gap-2 text-xs text-muted-foreground"><BedDouble size={15} /><select value={filters.minBedrooms} onChange={(e) => update('minBedrooms', e.target.value)} className="bg-transparent font-medium text-foreground outline-none" data-testid="select-bedrooms"><option value="">Any beds</option>{[1,2,3,4,5].map(n => <option key={n} value={n}>{n}+ beds</option>)}</select></label>
              <button onClick={clearFilters} type="button" className="text-xs font-semibold text-primary hover:underline" data-testid="button-clear-filters">Reset</button>
            </div>
          </div>
        </form>
      </section>

      <section className="site-shell pb-8 pt-12">
        <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
          <div><p className="eyebrow mb-2 text-accent">A good place to begin</p><h2 className="serif text-3xl font-semibold tracking-[-.04em] sm:text-[38px]">Homes worth coming home to</h2></div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <ArrowDownUp size={15} /><label htmlFor="sort-listings">Sort by</label>
            <select id="sort-listings" value={filters.sort} onChange={(e) => { update('sort', e.target.value); const next = { ...filters, sort: e.target.value }; setActive(next); setLocation(`/?${new URLSearchParams(Object.entries(next).filter(([,v]) => !!v && v !== 'recent')).toString()}`); }} className="rounded-lg border border-border bg-card px-3 py-2 font-medium text-foreground outline-none" data-testid="select-sort">
              <option value="recent">Most recent</option><option value="price_asc">Price: low to high</option><option value="price_desc">Price: high to low</option>
            </select>
          </div>
        </div>
        {listings.isLoading ? <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{[1,2,3,4,5,6].map(n => <div key={n} className="overflow-hidden rounded-[20px] border border-border bg-card"><div className="h-[218px] animate-pulse bg-secondary" /><div className="space-y-3 p-5"><div className="h-5 w-3/4 animate-pulse rounded bg-secondary" /><div className="h-4 w-1/2 animate-pulse rounded bg-secondary" /><div className="h-4 w-2/3 animate-pulse rounded bg-secondary" /></div></div>)}</div> :
          listings.isError ? <div className="rounded-2xl border border-border bg-card px-6 py-12 text-center" data-testid="status-listings-error"><p className="serif text-2xl">We couldn't reach the listings.</p><p className="mt-2 text-sm text-muted-foreground">Please try again in a moment.</p><button onClick={() => listings.refetch()} className="mt-5 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground" data-testid="button-retry-listings">Try again</button></div> :
          listings.data?.length ? <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{listings.data.map((property, i) => <div key={property.id} className="reveal" style={{ animationDelay: `${Math.min(i * 50, 250)}ms` }}><PropertyCard property={property} /></div>)}</div> :
            <div className="rounded-[24px] border border-dashed border-border bg-card/60 px-6 py-14 text-center" data-testid="status-listings-empty"><div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary text-primary"><Search size={20} /></div><h3 className="serif mt-4 text-2xl font-semibold">No homes match just yet</h3><p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-muted-foreground">Try a nearby city, widen your budget, or clear a filter to see more possibilities.</p><button onClick={clearFilters} className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-primary hover:underline" data-testid="button-empty-reset">Clear your filters <ArrowRight size={15} /></button></div>}
        {listings.data?.length ? <p className="mt-7 text-center text-xs text-muted-foreground" data-testid="text-listing-count">{listings.data.length} {listings.data.length === 1 ? 'home' : 'homes'} currently in view</p> : null}
      </section>
      <section className="site-shell pb-4 pt-7">
        <div className="flex flex-col items-start justify-between gap-5 rounded-[24px] bg-[#e8e1d2] p-7 sm:flex-row sm:items-center sm:p-9">
          <div><p className="eyebrow mb-2 text-accent">For homeowners</p><h2 className="serif text-2xl font-semibold tracking-[-.03em] sm:text-3xl">The right person is looking for your place.</h2><p className="mt-2 text-sm text-muted-foreground">Share a few details. We’ll take it from there.</p></div>
          <Link href="/list-property" className="inline-flex shrink-0 items-center gap-3 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition hover:bg-primary/90" data-testid="link-home-list">List your property <ArrowRight size={16} /></Link>
        </div>
      </section>
    </MarketShell>
  );
}