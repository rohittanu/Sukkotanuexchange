import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { useQueryClient } from '@tanstack/react-query';
import { getListPropertiesQueryKey, getGetPropertySummaryQueryKey, useCreateProperty } from '@workspace/api-client-react';
import type { PropertyInput } from '@workspace/api-client-react';
import { ArrowLeft, ArrowRight, CheckCircle2, CircleHelp, Home, ImagePlus, IndianRupee, MapPin } from 'lucide-react';
import { MarketShell } from '@/components/market-shell';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';

const schema = z.object({
  title: z.string().min(5, 'Add a little more detail to the title.').max(120),
  description: z.string().min(20, 'Please share at least 20 characters about the home.').max(3000),
  transactionType: z.enum(['buy', 'rent']),
  propertyType: z.enum(['apartment', 'house', 'villa', 'townhouse', 'land']),
  price: z.coerce.number().min(1, 'Enter a price greater than zero.'),
  city: z.string().min(1, 'City is required.'),
  locality: z.string().min(1, 'Locality is required.'),
  state: z.string().min(1, 'State is required.'),
  bedrooms: z.coerce.number().min(0).max(20),
  bathrooms: z.coerce.number().min(0).max(20),
  areaSqft: z.coerce.number().min(1, 'Enter the area in square feet.'),
  imageUrl: z.string().url('Enter a valid image URL.'),
  sellerName: z.string().min(1, 'Your name is required.').max(120),
  sellerEmail: z.string().email('Enter a valid email address.'),
});
type ListingForm = z.input<typeof schema>;

const defaults: ListingForm = {
  title: '', description: '', transactionType: 'buy', propertyType: 'apartment', price: 0, city: '', locality: '', state: '',
  bedrooms: 2, bathrooms: 1, areaSqft: 800, imageUrl: '', sellerName: '', sellerEmail: '',
};

function Field({ name, label, placeholder, type = 'text', testId }: { name: keyof ListingForm; label: string; placeholder?: string; type?: string; testId: string }) {
  return <FormField name={name} render={({ field }) => <FormItem><FormLabel className="text-xs font-semibold text-foreground">{label}</FormLabel><FormControl><input {...field} type={type} placeholder={placeholder} min={type === 'number' ? 0 : undefined} className="field" data-testid={testId} /></FormControl><FormMessage /></FormItem>} />;
}

export default function ListPropertyPage() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const createProperty = useCreateProperty();
  const [publishedTitle, setPublishedTitle] = useState('');
  const form = useForm<ListingForm, unknown, PropertyInput>({ resolver: zodResolver(schema), defaultValues: defaults });
  const submit = form.handleSubmit((data) => {
    createProperty.mutate({ data }, {
      onSuccess: (created) => {
        void queryClient.invalidateQueries({ queryKey: getListPropertiesQueryKey() });
        void queryClient.invalidateQueries({ queryKey: getGetPropertySummaryQueryKey() });
        setPublishedTitle(created.title);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      },
    });
  });

  if (publishedTitle) return <MarketShell><div className="site-shell py-20"><div className="mx-auto max-w-xl rounded-[28px] border border-border bg-card p-8 text-center sm:p-12" data-testid="status-listing-published"><span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary text-primary"><CheckCircle2 size={27} /></span><p className="eyebrow mt-6 text-accent">Listing published</p><h1 className="serif mt-3 text-4xl font-semibold tracking-[-.04em]">Your home is out there.</h1><p className="mt-4 text-sm leading-6 text-muted-foreground"><strong className="text-foreground">{publishedTitle}</strong> is now part of Sukko Exchange. Thank you for sharing it with someone searching for a place to call their own.</p><div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row"><Link href="/" className="rounded-full bg-primary px-5 py-3 text-sm font-bold text-primary-foreground" data-testid="link-view-listings">Explore homes</Link><button onClick={() => { setPublishedTitle(''); form.reset(defaults); }} className="rounded-full border border-border px-5 py-3 text-sm font-bold text-foreground hover:bg-secondary" data-testid="button-add-another">Add another home</button></div></div></div></MarketShell>;

  return (
    <MarketShell>
      <div className="site-shell pb-16 pt-7">
        <Link href="/" className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-primary" data-testid="link-back-home"><ArrowLeft size={16} /> Back to homes</Link>
        <div className="mt-6 grid items-start gap-9 lg:grid-cols-[minmax(0,1fr)_300px]">
          <div>
            <div className="mb-8 max-w-2xl"><p className="eyebrow mb-3 text-accent">Share a place, open a possibility</p><h1 className="serif text-[42px] font-semibold leading-[1.05] tracking-[-.05em] sm:text-[54px]">List your property.</h1><p className="mt-4 max-w-xl text-sm leading-6 text-muted-foreground">A clear, honest listing helps the right person picture their life there. Tell them what makes it special.</p></div>
            {createProperty.isError && <div className="mb-5 rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive" role="alert" data-testid="status-publish-error">We couldn’t publish this listing. Please check your details and try again.</div>}
            <Form {...form}>
              <form onSubmit={submit} className="space-y-7" data-testid="form-list-property">
                <section className="rounded-[22px] border border-border bg-card p-5 sm:p-7">
                  <div className="mb-6 flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-secondary text-primary"><Home size={18} /></span><div><h2 className="font-semibold">The essentials</h2><p className="text-xs text-muted-foreground">What are you sharing?</p></div></div>
                  <div className="grid gap-5 sm:grid-cols-2">
                    <div className="sm:col-span-2"><Field name="title" label="Listing title" placeholder="e.g. Sunlit 2BHK near Indiranagar metro" testId="input-title" /></div>
                    <FormField name="transactionType" render={({ field }) => <FormItem><FormLabel className="text-xs font-semibold">I want to</FormLabel><FormControl><select {...field} className="field" data-testid="select-transaction-type"><option value="buy">Sell this property</option><option value="rent">Rent this property</option></select></FormControl><FormMessage /></FormItem>} />
                    <FormField name="propertyType" render={({ field }) => <FormItem><FormLabel className="text-xs font-semibold">Property type</FormLabel><FormControl><select {...field} className="field" data-testid="select-listing-property-type"><option value="apartment">Apartment</option><option value="house">Independent house</option><option value="villa">Villa</option><option value="townhouse">Townhouse</option><option value="land">Land</option></select></FormControl><FormMessage /></FormItem>} />
                    <div className="sm:col-span-2"><FormField name="description" render={({ field }) => <FormItem><FormLabel className="text-xs font-semibold">Tell us about the home</FormLabel><FormControl><textarea {...field} rows={5} maxLength={3000} placeholder="Share the details people want to know: light, layout, nearby essentials, and what you love about the neighbourhood." className="field resize-y leading-6" data-testid="input-description" /></FormControl><div className="flex items-center justify-between"><FormMessage /><span className="text-[11px] text-muted-foreground">{form.watch('description')?.length ?? 0} / 3000</span></div></FormItem>} /></div>
                  </div>
                </section>

                <section className="rounded-[22px] border border-border bg-card p-5 sm:p-7">
                  <div className="mb-6 flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-secondary text-primary"><MapPin size={18} /></span><div><h2 className="font-semibold">Where it is</h2><p className="text-xs text-muted-foreground">Help people find the neighbourhood.</p></div></div>
                  <div className="grid gap-5 sm:grid-cols-3"><Field name="locality" label="Locality" placeholder="Koramangala" testId="input-locality" /><Field name="city" label="City" placeholder="Bengaluru" testId="input-listing-city" /><Field name="state" label="State" placeholder="Karnataka" testId="input-state" /></div>
                </section>

                <section className="rounded-[22px] border border-border bg-card p-5 sm:p-7">
                  <div className="mb-6 flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-secondary text-primary"><IndianRupee size={18} /></span><div><h2 className="font-semibold">The numbers</h2><p className="text-xs text-muted-foreground">Useful details for a considered decision.</p></div></div>
                  <div className="grid gap-5 sm:grid-cols-2"><Field name="price" label="Price (₹)" placeholder="12500000" type="number" testId="input-price" /><Field name="areaSqft" label="Area (sq ft)" placeholder="1200" type="number" testId="input-area" /><Field name="bedrooms" label="Bedrooms" type="number" testId="input-bedrooms" /><Field name="bathrooms" label="Bathrooms" type="number" testId="input-bathrooms" /></div>
                  <p className="mt-4 flex gap-2 text-xs leading-5 text-muted-foreground"><CircleHelp size={14} className="mt-0.5 shrink-0" />For rentals, enter the monthly rent. For a sale, enter the total asking price.</p>
                </section>

                <section className="rounded-[22px] border border-border bg-card p-5 sm:p-7">
                  <div className="mb-6 flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-secondary text-primary"><ImagePlus size={18} /></span><div><h2 className="font-semibold">A first look</h2><p className="text-xs text-muted-foreground">Add a direct link to a property photo.</p></div></div>
                  <Field name="imageUrl" label="Image URL" placeholder="https://example.com/home-photo.jpg" testId="input-image-url" />
                </section>

                <section className="rounded-[22px] border border-border bg-card p-5 sm:p-7">
                  <div className="mb-6"><h2 className="font-semibold">Who should they contact?</h2><p className="mt-1 text-xs text-muted-foreground">Your details help interested people reach you directly.</p></div>
                  <div className="grid gap-5 sm:grid-cols-2"><Field name="sellerName" label="Your name" placeholder="Name to share with enquiries" testId="input-seller-name" /><Field name="sellerEmail" label="Email address" placeholder="you@example.com" type="email" testId="input-seller-email" /></div>
                </section>
                <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center"><p className="max-w-sm text-xs leading-5 text-muted-foreground">By publishing, you confirm that the details are accurate and that you’re authorised to share this listing.</p><Button type="submit" disabled={createProperty.isPending} className="h-12 w-full gap-2 rounded-full px-7 text-sm font-bold sm:w-auto" data-testid="button-publish-listing">{createProperty.isPending ? 'Publishing your home…' : 'Publish listing'}<ArrowRight size={16} /></Button></div>
              </form>
            </Form>
          </div>
          <aside className="rounded-[22px] bg-primary p-6 text-primary-foreground lg:sticky lg:top-7">
            <p className="eyebrow text-[#d7b99b]">A good listing feels human</p><h2 className="serif mt-3 text-2xl leading-tight">The little details help someone imagine life there.</h2>
            <ul className="mt-6 space-y-4 text-sm leading-5 text-primary-foreground/75"><li className="flex gap-3"><span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[#edb18e]" />Describe the light, layout, and daily conveniences.</li><li className="flex gap-3"><span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[#edb18e]" />Use a photo that reflects the real home.</li><li className="flex gap-3"><span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[#edb18e]" />Share a price that helps people plan.</li></ul>
            <div className="mt-7 border-t border-white/15 pt-5"><Link href="/" className="inline-flex items-center gap-2 text-xs font-semibold text-[#edb18e] hover:text-white" data-testid="link-listing-help-back">Browse the marketplace <ArrowRight size={14} /></Link></div>
          </aside>
        </div>
      </div>
    </MarketShell>
  );
}