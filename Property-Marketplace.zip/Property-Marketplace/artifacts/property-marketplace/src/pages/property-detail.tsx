import { Link, useRoute } from 'wouter';
import { useGetProperty, getGetPropertyQueryKey } from '@workspace/api-client-react';
import { ArrowLeft, ArrowUpRight, Bath, BedDouble, CalendarDays, Check, MapPin, Ruler, ShieldCheck } from 'lucide-react';
import { MarketShell, formatINR, PropertyPhoto } from '@/components/market-shell';

export default function PropertyDetailPage() {
  const [, params] = useRoute('/property/:id');
  const parsedId = Number(params?.id);
  const validId = Number.isInteger(parsedId) && parsedId > 0;
  const property = useGetProperty(validId ? parsedId : 0, { query: { enabled: validId, queryKey: getGetPropertyQueryKey(validId ? parsedId : 0) } });

  if (!validId) return <MarketShell><div className="site-shell py-24 text-center"><p className="serif text-3xl">That home couldn’t be found.</p><Link href="/" className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-primary" data-testid="link-back-browse"><ArrowLeft size={15} /> Back to homes</Link></div></MarketShell>;
  if (property.isLoading) return <MarketShell><div className="site-shell py-10"><div className="h-[420px] animate-pulse rounded-[26px] bg-secondary" /><div className="mt-7 h-8 w-2/3 animate-pulse rounded bg-secondary" /><div className="mt-4 h-5 w-1/3 animate-pulse rounded bg-secondary" /></div></MarketShell>;
  if (property.isError || !property.data) return <MarketShell><div className="site-shell py-24 text-center" data-testid="status-property-error"><p className="serif text-3xl">This listing isn’t available right now.</p><p className="mt-2 text-sm text-muted-foreground">It may have been removed, or the connection was interrupted.</p><button onClick={() => property.refetch()} className="mt-5 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground" data-testid="button-retry-property">Try again</button><div><Link href="/" className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-primary" data-testid="link-back-browse"><ArrowLeft size={15} /> Browse other homes</Link></div></div></MarketShell>;

  const home = property.data;
  const subject = `I'm interested in ${home.title}`;
  const body = `Hello ${home.sellerName},\n\nI found your property on Sukko Exchange and would love to know more.\n\nProperty: ${home.title}\nLocation: ${home.locality}, ${home.city}\n\nPlease let me know a good time to speak.\n\nThank you`;
  const emailHref = `mailto:${encodeURIComponent(home.sellerEmail)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  const created = new Date(home.createdAt);

  return (
    <MarketShell>
      <div className="site-shell pb-12 pt-7">
        <Link href="/" className="mb-5 inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground transition hover:text-primary" data-testid="link-back-browse"><ArrowLeft size={16} /> All homes</Link>
        <div className="relative h-[300px] overflow-hidden rounded-[24px] sm:h-[430px]">
          <PropertyPhoto src={home.imageUrl} title={home.title} className="h-full w-full" />
          <div className="image-wash absolute inset-0" />
          <div className="absolute bottom-5 left-5 flex flex-wrap gap-2 sm:bottom-8 sm:left-8">
            <span className="rounded-full bg-card px-3 py-1.5 text-[10px] font-bold uppercase tracking-[.12em] text-primary">{home.transactionType === 'buy' ? 'For sale' : 'For rent'}</span>
            {home.featured && <span className="rounded-full bg-accent px-3 py-1.5 text-[10px] font-bold uppercase tracking-[.12em] text-accent-foreground">Featured home</span>}
          </div>
          <p className="absolute bottom-6 right-6 font-serif text-3xl font-semibold text-white sm:bottom-8 sm:right-8 sm:text-4xl" data-testid="text-detail-price">{formatINR(home.price, true)}{home.transactionType === 'rent' ? <span className="font-sans text-sm font-medium"> / month</span> : null}</p>
        </div>
        <div className="grid gap-10 pt-8 lg:grid-cols-[1fr_340px]">
          <div>
            <p className="eyebrow mb-3 text-accent">{home.propertyType} · {home.transactionType === 'buy' ? 'For sale' : 'For rent'}</p>
            <h1 className="serif max-w-3xl text-[36px] font-semibold leading-[1.08] tracking-[-.045em] sm:text-5xl" data-testid="text-property-title">{home.title}</h1>
            <p className="mt-4 flex items-center gap-2 text-sm text-muted-foreground" data-testid="text-property-location"><MapPin size={16} className="text-accent" />{home.locality}, {home.city}, {home.state}</p>
            <div className="mt-7 flex flex-wrap gap-x-7 gap-y-4 border-y border-border py-5 text-sm">
              {home.bedrooms > 0 && <span className="flex items-center gap-2"><BedDouble size={17} className="text-primary" />{home.bedrooms} bedrooms</span>}
              {home.bathrooms > 0 && <span className="flex items-center gap-2"><Bath size={17} className="text-primary" />{home.bathrooms} bathrooms</span>}
              <span className="flex items-center gap-2"><Ruler size={17} className="text-primary" />{new Intl.NumberFormat('en-IN').format(home.areaSqft)} sq ft</span>
            </div>
            <section className="pt-7">
              <h2 className="serif text-2xl font-semibold">A little about the home</h2>
              <p className="mt-4 max-w-3xl whitespace-pre-line text-[15px] leading-7 text-muted-foreground" data-testid="text-property-description">{home.description}</p>
            </section>
            <div className="mt-8 flex items-start gap-3 rounded-2xl border border-border bg-card p-5">
              <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-secondary text-primary"><ShieldCheck size={19} /></span>
              <div><p className="text-sm font-semibold">Make your decision with confidence</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Speak directly with the person sharing this home. Always verify documents and details in person before making a commitment.</p></div>
            </div>
          </div>
          <aside className="h-fit rounded-[22px] border border-border bg-card p-6 lg:sticky lg:top-6">
            <p className="eyebrow text-accent">Your next conversation</p>
            <h2 className="serif mt-2 text-2xl font-semibold">Talk to the owner</h2>
            <div className="mt-5 flex items-center gap-3 border-b border-border pb-5">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-secondary font-serif text-lg font-semibold text-primary">{home.sellerName.trim().split(/\s+/).map(part => part[0]).slice(0,2).join('').toUpperCase()}</span>
              <div><p className="font-semibold" data-testid="text-seller-name">{home.sellerName}</p><p className="mt-0.5 text-xs text-muted-foreground">Property owner / seller</p></div>
            </div>
            <a href={emailHref} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3.5 text-sm font-bold text-primary-foreground transition hover:bg-primary/90" data-testid="link-contact-seller">Email about this home <ArrowUpRight size={16} /></a>
            <p className="mt-3 text-center text-[11px] leading-5 text-muted-foreground">Your email app will open with a message ready to send.</p>
            {home.createdAt && <p className="mt-6 flex items-center gap-2 border-t border-border pt-4 text-xs text-muted-foreground"><CalendarDays size={14} />Listed {Number.isNaN(created.getTime()) ? 'recently' : created.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</p>}
            <p className="mt-3 flex items-center gap-2 text-[11px] text-primary"><Check size={13} /> Contact details shared by the listing owner</p>
          </aside>
        </div>
      </div>
    </MarketShell>
  );
}