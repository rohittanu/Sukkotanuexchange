# Property Marketplace

Gharonda helps people in India browse homes for sale or rent, contact owners directly, and publish property listings.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/property-marketplace/` — React marketplace UI and bundled listing photos
- `artifacts/api-server/src/routes/properties.ts` — listing search, detail, create, and marketplace summary APIs
- `lib/api-spec/openapi.yaml` — API contract and generated client source
- `lib/db/src/schema/properties.ts` — PostgreSQL property listing table
- `artifacts/property-marketplace/src/index.css` — shared theme and global styles

## Architecture decisions

- Listings and market totals are stored in PostgreSQL; demo listings seed the initial browse experience.
- Contacting a seller opens a prefilled email draft using the seller's published email address; the marketplace does not send mail itself.
- Property prices use Indian rupees, with rent treated as a monthly amount.
- Listings are public and do not require an account in this initial version.

## Product

- Search, filter, and sort homes for sale or rent.
- View full listing details and contact the seller by email.
- Publish a listing with property details, photo URL, and seller contact information.
- Browse summary counts for listings, sale/rent inventory, and cities.

## User preferences

_No additional preferences have been stated._

## Gotchas

- Regenerate API client and validation schemas with `pnpm --filter @workspace/api-spec run codegen` after changing `lib/api-spec/openapi.yaml`.
- Push development database schema changes with `pnpm --filter @workspace/db run push`.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
